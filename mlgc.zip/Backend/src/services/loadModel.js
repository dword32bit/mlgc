const tf = require('@tensorflow/tfjs');
require('@tensorflow/tfjs-backend-cpu');
async function loadModel() {
    return tf.loadGraphModel('https://storage.googleapis.com/storage-cancer-prediction-tesis/model.json'); //HERE
}
module.exports = loadModel;